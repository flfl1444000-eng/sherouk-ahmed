SHOROUQ & AHMED — WEBSITE
1) Extract the ZIP.
2) Keep index.html and the assets folder together.
3) Open index.html in Chrome/Edge.
4) Press "Enter Our Story" to enter and start the music (browsers require a user tap before audio can play).
The site includes the supplied photos, the supplied memory video, and the audio-only MP3 extracted from the separate video.
For publishing online, upload the entire folder while preserving the assets folder.


Suggested public site name / URL slug: ahmed-and-sherouk
Suggested Firebase Hosting URL (only if available): https://ahmed-and-sherouk.web.app

IMPORTANT: This ZIP is prepared for publishing but has NOT been uploaded online. A Google/Firebase account owner must sign in, create a Hosting project, and deploy this folder. After deployment, add the live URL in Google Search Console and request indexing. Google search visibility is not immediate or guaranteed.
